# Machine-Learning-Approach-to-Flood-Prediction
Rising Waters: A Machine Learning Approach to Flood Prediction is a web-based system that predicts flood risk using historical rainfall and weather data. The model is built using machine learning algorithms and deployed with Flask to provide real-time flood predictions through a simple user interface.
